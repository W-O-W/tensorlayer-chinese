:mod:`tensorlayer.iterate`
==========================

.. automodule:: tensorlayer.iterate

.. autosummary::

   minibatches
   seq_minibatches
   ptb_iterator


Iteration functions
--------------------

.. autofunction:: minibatches
.. autofunction:: seq_minibatches
.. autofunction:: ptb_iterator
