:mod:`tensorlayer.nlp`
======================

.. automodule:: tensorlayer.nlp

.. autosummary::

   generate_skip_gram_batch


Word embedding functions
---------------------------

.. autofunction:: generate_skip_gram_batch
