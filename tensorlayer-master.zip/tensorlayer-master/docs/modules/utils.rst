:mod:`tensorlayer.utils`
========================

.. automodule:: tensorlayer.utils

.. autosummary::

   evaluation
   class_balancing_oversample
   dict_to_one

Evaluation functions
---------------------

.. autofunction:: evaluation


Class balancing functions
----------------------------

.. autofunction:: class_balancing_oversample


Helper functions
--------------------

.. autofunction:: dict_to_one
