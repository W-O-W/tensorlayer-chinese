:mod:`tensorlayer.preprocess`
============================

.. automodule:: tensorlayer.preprocess

.. autosummary::

   distorted_images
   crop_central_whiten_images


Images
--------------------

.. autofunction:: distorted_images

.. autofunction:: crop_central_whiten_images
